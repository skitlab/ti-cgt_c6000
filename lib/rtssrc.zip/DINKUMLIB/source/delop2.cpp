// delop2 -- operator delete(void *, nothrow_t) REPLACEABLE
#include <new>

void operator delete(void *ptr,
	const _STD nothrow_t&) _THROW0()
	{	// free an allocated object
	operator delete(ptr);
	}

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
