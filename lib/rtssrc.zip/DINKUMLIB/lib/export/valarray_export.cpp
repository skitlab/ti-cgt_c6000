// EXPORTED FUNCTIONS
#include <valarray>
_STD_BEGIN

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator=(const valarray<_Ty>& _Right)
	{	// assign valarray _Right
	if (this == &_Right)
		;	// do nothing
	else if (size() == _Right.size())
		for (size_t _Idx = 0; _Idx < size(); ++_Idx)
			_Myptr[_Idx] = _Right[_Idx];
	else
		{	// resize and copy
		_Tidy(true);
		_Grow(_Right.size(), _Right._Myptr, 1);
		}
	return (*this);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator=(const _Ty& _Val)
	{	// assign _Val to each element
	_VALGOP(= _Val);
	}

template<class _Ty>
	valarray<_Ty> valarray<_Ty>::operator+() const
	{	// return +valarray
	_VALOP(_Ty, size(), +_Myptr[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> valarray<_Ty>::operator-() const
	{	// return -valarray
	_VALOP(_Ty, size(), -_Myptr[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> valarray<_Ty>::operator~() const
	{	// return ~valarray
	_VALOP(_Ty, size(), ~_Myptr[_Idx]);
	}

template<class _Ty>
	_Boolarray  valarray<_Ty>::operator!() const
	{	// return !valarray
	_VALOP(_Bool, size(), !_Myptr[_Idx]);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator*=(const _Ty& _Right)
	{	// multiply valarray elements by _Right
	_VALGOP(*= _Right);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator/=(const _Ty& _Right)
	{	// divide valarray elements by _Right
	_VALGOP(/= _Right);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator%=(const _Ty& _Right)
	{	// remainder valarray elements by _Right
	_VALGOP(%= _Right);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator+=(const _Ty& _Right)
	{	// add _Right to valarray elements
	_VALGOP(+= _Right);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator-=(const _Ty& _Right)
	{	// subtract _Right from valarray elements
	_VALGOP(-= _Right);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator^=(const _Ty& _Right)
	{	// XOR _Right into valarray elements
	_VALGOP(^= _Right);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator&=(const _Ty& _Right)
	{	// AND _Right into valarray elements
	_VALGOP(&= _Right);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator|=(const _Ty& _Right)
	{	// OR _Right into valarray elements
	_VALGOP(|= _Right);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator<<=(const _Ty& _Right)
	{	// left shift valarray elements by _Right
	_VALGOP(<<= _Right);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator>>=(const _Ty& _Right)
	{	// right shift valarray elements by _Right
	_VALGOP(>>= _Right);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator*=(const valarray<_Ty>& _Right)
	{	// multiply valarray elements by valarray _Right elements
	_VALGOP(*= _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator/=(const valarray<_Ty>& _Right)
	{	// divide valarray elements by valarray _Right elements
	_VALGOP(/= _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator%=(const valarray<_Ty>& _Right)
	{	// remainder valarray elements by valarray _Right elements
	_VALGOP(%= _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator+=(const valarray<_Ty>& _Right)
	{	// add valarray _Right elements to valarray elements
	_VALGOP(+= _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator-=(const valarray<_Ty>& _Right)
	{	// subtract valarray _Right elements from valarray elements
	_VALGOP(-= _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator^=(const valarray<_Ty>& _Right)
	{	// XOR valarray _Right elements into valarray elements
	_VALGOP(^= _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator|=(const valarray<_Ty>& _Right)
	{	// OR valarray _Right elements into valarray elements
	_VALGOP(|= _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator&=(const valarray<_Ty>& _Right)
	{	// AND valarray _Right elements into valarray elements
	_VALGOP(&= _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator<<=(const valarray<_Ty>& _Right)
	{	// left shift valarray elements by valarray _Right elements
	_VALGOP(<<= _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator>>=(const valarray<_Ty>& _Right)
	{	// right shift valarray elements by valarray _Right elements
	_VALGOP(>>= _Right[_Idx]);
	}

template<class _Ty>
	_Ty valarray<_Ty>::sum() const
	{	// return sum all elements
	_Ty _Sum = _Myptr[0];
	for (size_t _Idx = 0; ++_Idx < size(); )
		_Sum += _Myptr[_Idx];
	return (_Sum);
	}

template<class _Ty>
	_Ty valarray<_Ty>::min() const
	{	// return smallest of all elements
	_Ty _Min = _Myptr[0];
	for (size_t _Idx = 0; ++_Idx < size(); )
		if (_Myptr[_Idx] < _Min)
			_Min = _Myptr[_Idx];
	return (_Min);
	}

template<class _Ty>
	_Ty valarray<_Ty>::max() const
	{	// return largest of all elements
	_Ty _Max = _Myptr[0];
	for (size_t _Idx = 0; ++_Idx < size(); )
		if (_Max < _Myptr[_Idx])
			_Max = _Myptr[_Idx];
	return (_Max);
	}

template<class _Ty>
	valarray<_Ty> valarray<_Ty>::shift(int _Count) const
	{	// return valarray left shifted
	static _Ty _Dflt;
	_VALOP(_Ty, size(),
		0 < _Count && size() - _Idx <= (size_t)_Count
			|| _Count < 0 && _Idx  < (size_t)-_Count
				? _Dflt : _Myptr[_Idx + _Count]);
	}

template<class _Ty>
	valarray<_Ty> valarray<_Ty>::cshift(int _Count) const
	{	// return valarray left rotated
	if (size() == 0)
		;	// no shift
	else if (_Count < 0)
		{	// right shift
		if ((_Count += size()) < 0)
			_Count = size() - (-_Count) % size();
		}
	else if (size() <= (size_t)_Count)
		_Count %= size();

	_VALOP(_Ty, size(), size() - _Idx <= (size_t)_Count
		? _Myptr[_Idx - size() + _Count] : _Myptr[_Idx + _Count]);
	}

template<class _Ty>
	valarray<_Ty> valarray<_Ty>::apply(_Ty _Func(_Ty)) const
	{	// return valarray transformed by _Func, value argument
	_VALOP(_Ty, size(), _Func(_Myptr[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> valarray<_Ty>::apply(_Ty _Func(const _Ty&)) const
	{	// return valarray transformed by _Func, nonmutable argument
	_VALOP(_Ty, size(), _Func(_Myptr[_Idx]));
	}

template<class _Ty>
	void valarray<_Ty>::_Grow(size_t _Count,
	const _Ty *_Ptr,
	size_t _Inc,
	bool _Trim)
	{	// grow to _Count elements and pad, trim if _Trim is true
	size_t _Oldsize = _Myptr == 0 ? 0 : _Myres;

	if (_Count == 0)
		{	// new sequence empty
		if (_Trim)
			_Tidy(true);
		}
	else if (_Count == _Oldsize || _Count < _Oldsize && !_Trim)
		;	// big enough, no need to pad or trim
	else
		{	// allocate new array, copy and pad
		size_t _Idx;
		size_t _Newsize = _Myptr == 0 && _Count < _Myres
			? _Myres : _Count;
		_Ty *_Newptr = 0;
		size_t _Nm = _Count < _Mysize ? _Count : _Mysize;

		_TRY_BEGIN
		_Newptr = new _Ty[_Newsize];
		_CATCH_ALL
		_Tidy(true);	// allocation failed, discard storage and reraise
		_RERAISE;
		_CATCH_END

		for (_Idx = 0; _Idx < _Nm; ++_Idx)
			_Newptr[_Idx] = _Myptr[_Idx];
		if (_Ptr != 0)
			for (; _Idx < _Newsize; ++_Idx, _Ptr += _Inc)
				_Newptr[_Idx] = *_Ptr;

		_Tidy(true);
		_Myptr = _Newptr;
		_Myres = _Newsize;
		}
	_Mysize = _Count;
	}

template<class _Ty>
	valarray<_Ty> operator*(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray * scalar
	_VALOP(_Ty, _Left.size(), _Left[_Idx] * _Right);
	}

template<class _Ty>
	valarray<_Ty> operator*(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar * valarray
	_VALOP(_Ty, _Right.size(), _Left * _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator/(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray / scalar
	_VALOP(_Ty, _Left.size(), _Left[_Idx] / _Right);
	}

template<class _Ty>
	valarray<_Ty> operator/(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar / valarray
	_VALOP(_Ty, _Right.size(), _Left / _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator%(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray % scalar
	_VALOP(_Ty, _Left.size(), _Left[_Idx] % _Right);
	}

template<class _Ty>
	valarray<_Ty> operator%(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar % valarray
	_VALOP(_Ty, _Right.size(), _Left % _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator+(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray + scalar
	_VALOP(_Ty, _Left.size(), _Left[_Idx] + _Right);
	}

template<class _Ty>
	valarray<_Ty> operator+(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar + valarray
	_VALOP(_Ty, _Right.size(), _Left + _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator-(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray - scalar
	_VALOP(_Ty, _Left.size(), _Left[_Idx] - _Right);
	}

template<class _Ty>
	valarray<_Ty> operator-(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar - valarray
	_VALOP(_Ty, _Right.size(), _Left - _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator^(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray ^ scalar
	_VALOP(_Ty, _Left.size(), _Left[_Idx] ^ _Right);
	}

template<class _Ty>
	valarray<_Ty> operator^(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar ^ valarray
	_VALOP(_Ty, _Right.size(), _Left ^ _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator&(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray & scalar
	_VALOP(_Ty, _Left.size(), _Left[_Idx] & _Right);
	}

template<class _Ty>
	valarray<_Ty> operator&(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar & valarray
	_VALOP(_Ty, _Right.size(), _Left & _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator|(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray | scalar
	_VALOP(_Ty, _Left.size(), _Left[_Idx] | _Right);
	}

template<class _Ty>
	valarray<_Ty> operator|(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar | valarray
	_VALOP(_Ty, _Right.size(), _Left | _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator<<(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray << scalar
	_VALOP(_Ty, _Left.size(), _Left[_Idx] << _Right);
	}

template<class _Ty>
	valarray<_Ty> operator<<(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar << valarray
	_VALOP(_Ty, _Right.size(), _Left << _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator>>(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray >> scalar
	_VALOP(_Ty, _Left.size(), _Left[_Idx] >> _Right);
	}

template<class _Ty>
	valarray<_Ty> operator>>(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar >> valarray
	_VALOP(_Ty, _Right.size(), _Left >> _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator&&(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray && scalar
	_VALOP(_Bool, _Left.size(), _Left[_Idx] && _Right);
	}

template<class _Ty>
	_Boolarray operator&&(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar && valarray
	_VALOP(_Bool, _Right.size(), _Left && _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator||(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray || scalar
	_VALOP(_Bool, _Left.size(), _Left[_Idx] || _Right);
	}

template<class _Ty>
	_Boolarray operator||(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar || valarray
	_VALOP(_Bool, _Right.size(), _Left || _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator*(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray * valarray
	_VALOP(_Ty, _Left.size(), _Left[_Idx] * _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator/(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray ? valarray
	_VALOP(_Ty, _Left.size(), _Left[_Idx] / _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator%(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray % valarray
	_VALOP(_Ty, _Left.size(), _Left[_Idx] % _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator+(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray + valarray
	_VALOP(_Ty, _Left.size(), _Left[_Idx] + _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator-(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray - valarray
	_VALOP(_Ty, _Left.size(), _Left[_Idx] - _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator^(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray ^ valarray
	_VALOP(_Ty, _Left.size(), _Left[_Idx] ^ _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator&(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray & valarray
	_VALOP(_Ty, _Left.size(), _Left[_Idx] & _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator|(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray | valarray
	_VALOP(_Ty, _Left.size(), _Left[_Idx] | _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator<<(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray << valarray
	_VALOP(_Ty, _Left.size(), _Left[_Idx] << _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> operator>>(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray >> valarray
	_VALOP(_Ty, _Left.size(), _Left[_Idx] >> _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator&&(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray && valarray
	_VALOP(_Bool, _Left.size(), _Left[_Idx] && _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator||(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray || valarray
	_VALOP(_Bool, _Left.size(), _Left[_Idx] || _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator==(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray == scalar
	_VALOP(_Bool, _Left.size(), _Left[_Idx] == _Right);
	}

template<class _Ty>
	_Boolarray operator==(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar == valarray
	_VALOP(_Bool, _Right.size(), _Left == _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator==(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray == valarray
	_VALOP(_Bool, _Left.size(), _Left[_Idx] == _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator!=(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray != scalar
	_VALOP(_Bool, _Left.size(), _Left[_Idx] != _Right);
	}

template<class _Ty>
	_Boolarray operator!=(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar != valarray
	_VALOP(_Bool, _Right.size(), _Left != _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator!=(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray != valarray
	_VALOP(_Bool, _Left.size(), _Left[_Idx] != _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator<(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray < scalar
	_VALOP(_Bool, _Left.size(), _Left[_Idx] < _Right);
	}

template<class _Ty>
	_Boolarray operator<(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar < valarray
	_VALOP(_Bool, _Right.size(), _Left < _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator<(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray < valarray
	_VALOP(_Bool, _Left.size(), _Left[_Idx] < _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator>(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray > scalar
	_VALOP(_Bool, _Left.size(), _Left[_Idx] > _Right);
	}

template<class _Ty>
	_Boolarray operator>(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar > valarray
	_VALOP(_Bool, _Right.size(), _Left > _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator>(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray > valarray
	_VALOP(_Bool, _Left.size(), _Left[_Idx] > _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator<=(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray <= scalar
	_VALOP(_Bool, _Left.size(), _Left[_Idx] <= _Right);
	}

template<class _Ty>
	_Boolarray operator<=(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar <= valarray
	_VALOP(_Bool, _Right.size(), _Left <= _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator<=(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray <= valarray
	_VALOP(_Bool, _Left.size(), _Left[_Idx] <= _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator>=(const valarray<_Ty>& _Left,
		const _Ty& _Right)
	{	// return valarray >= scalar
	_VALOP(_Bool, _Left.size(), _Left[_Idx] >= _Right);
	}

template<class _Ty>
	_Boolarray operator>=(const _Ty& _Left,
		const valarray<_Ty>& _Right)
	{	// return scalar >= valarray
	_VALOP(_Bool, _Right.size(), _Left >= _Right[_Idx]);
	}

template<class _Ty>
	_Boolarray operator>=(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// return valarray >= valarray
	_VALOP(_Bool, _Left.size(), _Left[_Idx] >= _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty> abs(const valarray<_Ty>& _Left)
	{	// apply abs to each element of valarray
	_VALOP(_Ty, _Left.size(), abs(_Left[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> acos(const valarray<_Ty>& _Left)
	{	// apply acos to each element of valarray
	_VALOP(_Ty, _Left.size(), _CSTD acos(_Left[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> asin(const valarray<_Ty>& _Left)
	{	// apply asin to each element of valarray
	_VALOP(_Ty, _Left.size(), _CSTD asin(_Left[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> atan(const valarray<_Ty>& _Left)
	{	// apply atan to each element of valarray
	_VALOP(_Ty, _Left.size(), _CSTD atan(_Left[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> atan2(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// apply atan2 to pairs of valarray elements
	_VALOP(_Ty, _Left.size(), _CSTD atan2(_Left[_Idx], _Right[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> atan2(const valarray<_Ty>& _Left, const _Ty& _Right)
	{	// apply atan2 to each valarray element and scalar
	_VALOP(_Ty, _Left.size(), _CSTD atan2(_Left[_Idx], _Right));
	}

template<class _Ty>
	valarray<_Ty> atan2(const _Ty& _Left, const valarray<_Ty>& _Right)
	{	// apply atan2 to scalar and each valarray element
	_VALOP(_Ty, _Right.size(), _CSTD atan2(_Left, _Right[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> cos(const valarray<_Ty>& _Left)
	{	// apply cos to each element of valarray
	_VALOP(_Ty, _Left.size(), _CSTD cos(_Left[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> cosh(const valarray<_Ty>& _Left)
	{	// apply cosh to each element of valarray
	_VALOP(_Ty, _Left.size(), _CSTD cosh(_Left[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> exp(const valarray<_Ty>& _Left)
	{	// apply exp to each element of valarray
	_VALOP(_Ty, _Left.size(), _CSTD exp(_Left[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> log(const valarray<_Ty>& _Left)
	{	// apply log to each element of valarray
	_VALOP(_Ty, _Left.size(), _CSTD log(_Left[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> log10(const valarray<_Ty>& _Left)
	{	// apply log10 to each element of valarray
	_VALOP(_Ty, _Left.size(), _CSTD log10(_Left[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> pow(const valarray<_Ty>& _Left,
		const valarray<_Ty>& _Right)
	{	// apply pow to pairs of valarray elements
	_VALOP(_Ty, _Left.size(), _CSTD pow(_Left[_Idx], _Right[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> pow(const valarray<_Ty>& _Left, const _Ty& _Right)
	{	// apply pow to each valarray element and scalar
	_VALOP(_Ty, _Left.size(), _CSTD pow(_Left[_Idx], _Right));
	}

template<class _Ty>
	valarray<_Ty> pow(const _Ty& _Left, const valarray<_Ty>& _Right)
	{	// apply pow to scalar and each valarray element
	_VALOP(_Ty, _Right.size(), _CSTD pow(_Left, _Right[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> sin(const valarray<_Ty>& _Left)
	{	// apply sin to each element of valarray
	_VALOP(_Ty, _Left.size(), _CSTD sin(_Left[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> sinh(const valarray<_Ty>& _Left)
	{	// apply sinh to each element of valarray
	_VALOP(_Ty, _Left.size(), _CSTD sinh(_Left[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> sqrt(const valarray<_Ty>& _Left)
	{	// apply sqrt to each element of valarray
	_VALOP(_Ty, _Left.size(), _CSTD sqrt(_Left[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> tan(const valarray<_Ty>& _Left)
	{	// apply tan to each element of valarray
	_VALOP(_Ty, _Left.size(), _CSTD tan(_Left[_Idx]));
	}

template<class _Ty>
	valarray<_Ty> tanh(const valarray<_Ty>& _Left)
	{	// apply tanh to each element of valarray
	_VALOP(_Ty, _Left.size(), _CSTD tanh(_Left[_Idx]));
	}

template<class _Ty>
	void slice_array<_Ty>::operator=(const valarray<_Ty>& _Right) const
	{	// assign a valarray to a slice
	_SLOP(= _Right[_Idx]);
	}

template<class _Ty>
	void slice_array<_Ty>::operator=(const _Ty& _Right) const
	{	// assign a scalar to elements of a slice
	_SLOP(= _Right);
	}

template<class _Ty>
	void slice_array<_Ty>::operator*=(const valarray<_Ty>& _Right) const
	{	// multiply slice by valarray
	_SLOP(*= _Right[_Idx]);
	}

template<class _Ty>
	void slice_array<_Ty>::operator/=(const valarray<_Ty>& _Right) const
	{	// divide slice by valarray
	_SLOP(/= _Right[_Idx]);
	}

template<class _Ty>
	void slice_array<_Ty>::operator%=(const valarray<_Ty>& _Right) const
	{	// remainder slice by valarray
	_SLOP(%= _Right[_Idx]);
	}

template<class _Ty>
	void slice_array<_Ty>::operator+=(const valarray<_Ty>& _Right) const
	{	// add slice to valarray
	_SLOP(+= _Right[_Idx]);
	}

template<class _Ty>
	void slice_array<_Ty>::operator-=(const valarray<_Ty>& _Right) const
	{	// subtract valarray from slice
	_SLOP(-= _Right[_Idx]);
	}

template<class _Ty>
	void slice_array<_Ty>::operator^=(const valarray<_Ty>& _Right) const
	{	// XOR valarray into slice
	_SLOP(^= _Right[_Idx]);
	}

template<class _Ty>
	void slice_array<_Ty>::operator&=(const valarray<_Ty>& _Right) const
	{	// AND valarray into slice
	_SLOP(&= _Right[_Idx]);
	}

template<class _Ty>
	void slice_array<_Ty>::operator|=(const valarray<_Ty>& _Right) const
	{	// OR valarray into slice
	_SLOP(|= _Right[_Idx]);
	}

template<class _Ty>
	void slice_array<_Ty>::operator<<=(const valarray<_Ty>& _Right) const
	{	// left shift slice by valarray
	_SLOP(<<= _Right[_Idx]);
	}

template<class _Ty>
	void slice_array<_Ty>::operator>>=(const valarray<_Ty>& _Right) const
	{	// right shift slice by valarray
	_SLOP(>>= _Right[_Idx]);
	}

template<class _Ty>
	void gslice_array<_Ty>::operator=(const valarray<_Ty>& _Right) const
	{	// assign a valarray to a generalized slice
	_GSLOP(= _Right[_Idx]);
	}

template<class _Ty>
	void gslice_array<_Ty>::operator=(const _Ty& _Right) const
	{	// assign a scalar to elements of a generalized slice
	_GSLOP(= _Right);
	}

template<class _Ty>
	void gslice_array<_Ty>::operator*=(const valarray<_Ty>& _Right) const
	{	// multiply generalized slice by valarray
	_GSLOP(*= _Right[_Idx]);
	}

template<class _Ty>
	void gslice_array<_Ty>::operator/=(const valarray<_Ty>& _Right) const
	{	// divide generalized slice by valarray
	_GSLOP(/= _Right[_Idx]);
	}

template<class _Ty>
	void gslice_array<_Ty>::operator%=(const valarray<_Ty>& _Right) const
	{	// remainder generalized slice by valarray
	_GSLOP(%= _Right[_Idx]);
	}

template<class _Ty>
	void gslice_array<_Ty>::operator+=(const valarray<_Ty>& _Right) const
	{	// add valarray to generalized slice
	_GSLOP(+= _Right[_Idx]);
	}

template<class _Ty>
	void gslice_array<_Ty>::operator-=(const valarray<_Ty>& _Right) const
	{	// subtract valarray from generalized slice
	_GSLOP(-= _Right[_Idx]);
	}

template<class _Ty>
	void gslice_array<_Ty>::operator^=(const valarray<_Ty>& _Right) const
	{	// XOR valarray into generalized slice
	_GSLOP(^= _Right[_Idx]);
	}

template<class _Ty>
	void gslice_array<_Ty>::operator&=(const valarray<_Ty>& _Right) const
	{	// AND valarray into generalized slice
	_GSLOP(&= _Right[_Idx]);
	}

template<class _Ty>
	void gslice_array<_Ty>::operator|=(const valarray<_Ty>& _Right) const
	{	// OR valarray into generalized slice
	_GSLOP(|= _Right[_Idx]);
	}

template<class _Ty>
	void gslice_array<_Ty>::operator<<=(const valarray<_Ty>& _Right) const
	{	// left shift generalized slice by valarray
	_GSLOP(<<= _Right[_Idx]);
	}

template<class _Ty>
	void gslice_array<_Ty>::operator>>=(const valarray<_Ty>& _Right) const
	{	// right shift generalized slice by valarray
	_GSLOP(>>= _Right[_Idx]);
	}

template<class _Ty>
	void mask_array<_Ty>::operator=(const valarray<_Ty>& _Right) const
	{	// assign a valarray to a masked array
	_MOP(= _Right[_Idx]);
	}

template<class _Ty>
	void mask_array<_Ty>::operator=(const _Ty& _Right) const
	{	// assign a scalar to elements of a masked array
	_MOP(= _Right);
	}

template<class _Ty>
	void mask_array<_Ty>::operator*=(const valarray<_Ty>& _Right) const
	{	// multiply masked array by valarray
	_MOP(*= _Right[_Idx]);
	}

template<class _Ty>
	void mask_array<_Ty>::operator/=(const valarray<_Ty>& _Right) const
	{	// divide masked array by valarray
	_MOP(/= _Right[_Idx]);
	}

template<class _Ty>
	void mask_array<_Ty>::operator%=(const valarray<_Ty>& _Right) const
	{	// remainder masked array by valarray
	_MOP(%= _Right[_Idx]);
	}

template<class _Ty>
	void mask_array<_Ty>::operator+=(const valarray<_Ty>& _Right) const
	{	// add valarray to masked array
	_MOP(+= _Right[_Idx]);
	}

template<class _Ty>
	void mask_array<_Ty>::operator-=(const valarray<_Ty>& _Right) const
	{	// subtract valarray from masked array
	_MOP(-= _Right[_Idx]);
	}

template<class _Ty>
	void mask_array<_Ty>::operator^=(const valarray<_Ty>& _Right) const
	{	// XOR valarray into masked array
	_MOP(^= _Right[_Idx]);
	}

template<class _Ty>
	void mask_array<_Ty>::operator&=(const valarray<_Ty>& _Right) const
	{	// OR valarray into masked array
	_MOP(&= _Right[_Idx]);
	}

template<class _Ty>
	void mask_array<_Ty>::operator|=(const valarray<_Ty>& _Right) const
	{	// OR valarray into masked array
	_MOP(|= _Right[_Idx]);
	}

template<class _Ty>
	void mask_array<_Ty>::operator<<=(const valarray<_Ty>& _Right) const
	{	// left shift masked array by valarray
	_MOP(<<= _Right[_Idx]);
	}

template<class _Ty>
	void mask_array<_Ty>::operator>>=(const valarray<_Ty>& _Right) const
	{	// right shift masked array by valarray
	_MOP(>>= _Right[_Idx]);
	}

template<class _Ty>
	size_t mask_array<_Ty>::_Totlen() const
	{	// return total length of masked array
	size_t _Count = 0;
	for (size_t _Idx = 0; _Idx < _Mybool.size(); ++_Idx)
		if (_Mybool[_Idx])
			++_Count;
	return (_Count);
	}

template<class _Ty>
	void indirect_array<_Ty>::operator=(const valarray<_Ty>& _Right) const
	{	// assign a valarray to an indirect array
	_IOP(= _Right[_Idx]);
	}

template<class _Ty>
	void indirect_array<_Ty>::operator=(const _Ty& _Right) const
	{	// assign a scalar to elements of an indirect array
	_IOP(= _Right);
	}

template<class _Ty>
	void indirect_array<_Ty>::operator*=(const valarray<_Ty>& _Right) const
	{	// multiply indirect array by valarray
	_IOP(*= _Right[_Idx]);
	}

template<class _Ty>
	void indirect_array<_Ty>::operator/=(const valarray<_Ty>& _Right) const
	{	// divide indirect array by valarray
	_IOP(/= _Right[_Idx]);
	}

template<class _Ty>
	void indirect_array<_Ty>::operator%=(const valarray<_Ty>& _Right) const
	{	// remainder indirect array by valarray
	_IOP(%= _Right[_Idx]);
	}

template<class _Ty>
	void indirect_array<_Ty>::operator+=(const valarray<_Ty>& _Right) const
	{	// add valarray to indirect array
	_IOP(+= _Right[_Idx]);
	}

template<class _Ty>
	void indirect_array<_Ty>::operator-=(const valarray<_Ty>& _Right) const
	{	// subtract valarray from indirect array
	_IOP(-= _Right[_Idx]);
	}

template<class _Ty>
	void indirect_array<_Ty>::operator^=(const valarray<_Ty>& _Right) const
	{	// XOR valarray into indirect array
	_IOP(^= _Right[_Idx]);
	}

template<class _Ty>
	void indirect_array<_Ty>::operator&=(const valarray<_Ty>& _Right) const
	{	// AND valarray into indirect array
	_IOP(&= _Right[_Idx]);
	}

template<class _Ty>
	void indirect_array<_Ty>::operator|=(const valarray<_Ty>& _Right) const
	{	// OR valarray into indirect array
	_IOP(|= _Right[_Idx]);
	}

template<class _Ty>
	void indirect_array<_Ty>::operator<<=(const valarray<_Ty>& _Right) const
	{	// left shift indirect array by valarray
	_IOP(<<= _Right[_Idx]);
	}

template<class _Ty>
	void indirect_array<_Ty>::operator>>=(const valarray<_Ty>& _Right) const
	{	// right shift indirect array by valarray
	_IOP(>>= _Right[_Idx]);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator=(
		const slice_array<_Ty>& _Slicearr)
	{	// assign slice array to valarray
	_Tidy(true);
	_Grow(_Slicearr.size(), &_Slicearr._Data(_Slicearr.start()),
		_Slicearr.stride());
	return (*this);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator=(
		const gslice_array<_Ty>& _Gslicearr)
	{	// assign generalized slice array to valarray
	_Tidy(true);
	_Grow(_Gslicearr._Totlen());
	_Sizarray _Indexarray((size_t)0, _Gslicearr._Nslice());
	_VALGOP(= _Gslicearr._Data(_Gslicearr._Off(_Indexarray)));
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator=(const mask_array<_Ty>& _Maskarr)
	{	// assign masked array to valarray
	_Tidy(true);
	_Grow(_Maskarr._Totlen());
	size_t _Count = 0;

	for (size_t _Idx = 0; _Idx < size(); ++_Count)
		if (_Maskarr._Mask(_Count))
			_Myptr[_Idx++] = _Maskarr._Data(_Count);
	return (*this);
	}

template<class _Ty>
	valarray<_Ty>& valarray<_Ty>::operator=(
		const indirect_array<_Ty>& _Indarr)
	{	// assign indirect array to valarray
	_Tidy(true);
	_Grow(_Indarr._Totlen());
	_VALGOP(= _Indarr._Data(_Indarr._Indir(_Idx)));
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
