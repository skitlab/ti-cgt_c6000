// EXPORTED FUNCTIONS
#include <locale>
_STD_BEGIN

template<class _Elem>
	typename collate<_Elem>::string_type collate<_Elem>::do_transform(const _Elem *_First,
	const _Elem *_Last) const
	{	// transform [_First, _Last) to key string
	_DEBUG_RANGE(_First, _Last);
	size_t _Count;
	string_type _Str;

	for (_Count = _Last - _First; 0 < _Count; )
		{	// grow string if locale-specific strxfrm fails
		_Str.resize(_Count);
		if ((_Count = _LStrxfrm(&*_Str.begin(),
			&*_Str.begin() + _Str.size(),
				_First, _Last, &_Coll)) <= _Str.size())
			break;
		}
	_Str.resize(_Count);
	return (_Str);
	}

template<class _Elem>
	long collate<_Elem>::do_hash(const _Elem *_First,
	const _Elem *_Last) const
	{	// compute hash code for [_First, _Last)
	_DEBUG_RANGE(_First, _Last);
	unsigned long _Val = 0;
	for (; _First != _Last; ++_First)
		_Val = (_Val << 8 | _Val >> 24) + *_First;
	return ((long)_Val);
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
