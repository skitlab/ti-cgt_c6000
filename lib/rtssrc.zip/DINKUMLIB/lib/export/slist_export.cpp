// EXPORTED FUNCTIONS
#include <slist>
_STD_BEGIN

template<class _Ty, class _Ax>
	void slist<_Ty, _Ax>::resize(size_type _Newsize, _Ty _Val)
	{	// determine new length, padding with _Val elements as needed
	if (_Mysize < _Newsize)
		insert(end(), _Newsize - _Mysize, _Val);
	else
		while (_Newsize < _Mysize)
			pop_back();
	}

template<class _Ty, class _Ax>
	void slist<_Ty, _Ax>::insert(iterator _Where,
	size_type _Count, const _Ty& _Val)
	{	// insert _Count * _Val at _Where
	_Nodeptr *_Pptr = _Getpptr(_Where);
	size_type _Countsave = _Count;

	_TRY_BEGIN
	for (; 0 < _Count; --_Count)
		_Insertp(_Pptr, _Val);
	_CATCH_ALL
	for (; _Count < _Countsave; ++_Count)
		_Erasep(_Pptr);	// undo inserts
	_RERAISE;
	_CATCH_END
	}

template<class _Ty, class _Ax>
	template<class _Iter>
	void slist<_Ty, _Ax>::_Insert(iterator _Where,
		_Iter _First, _Iter _Last, input_iterator_tag)
	{	// insert [_First, _Last) at _Where, input iterators
	_Nodeptr *_Pptr = _Getpptr(_Where);
	size_type _Num = 0;

	_TRY_BEGIN
	for (_Nodeptr *_Pptr2 = _Pptr; _First != _Last;
		++_First, ++_Num, _Pptr2 = &_Nextnode(*_Pptr2))
		_Insertp(_Pptr2, *_First);
	_CATCH_ALL
	for (; 0 < _Num; --_Num)
		_Erasep(_Pptr);	// undo inserts
	_RERAISE;
	_CATCH_END
	}

template<class _Ty, class _Ax>
	template<class _Iter>
	void slist<_Ty, _Ax>::_Insert(iterator _Where,
		_Iter _First, _Iter _Last, forward_iterator_tag)
	{	// insert [_First, _Last) at _Where, forward iterators
	_DEBUG_RANGE(_First, _Last);
	_Nodeptr *_Pptr = _Getpptr(_Where);
	_Iter _Next = _First;

	_TRY_BEGIN
	for (_Nodeptr *_Pptr2 = _Pptr; _First != _Last;
		++_First, _Pptr2 = &_Nextnode(*_Pptr2))
		_Insertp(_Pptr2, *_First);
	_CATCH_ALL
	for (; _Next != _First; ++_Next)
		_Erasep(_Pptr);	// undo inserts
	_RERAISE;
	_CATCH_END
	}

template<class _Ty, class _Ax>
	typename slist<_Ty, _Ax>::iterator slist<_Ty, _Ax>::erase(iterator _First, iterator _Last)
	{	// erase [_First, _Last)
	if (_First == begin() && _Last == end())
		{	// erase all
		clear();
		return (end());
		}
	else
		{	// erase subrange
		_Nodeptr *_Pptr = _Getpptr(_First);
		for (bool _Done = _First == _Last; !_Done; )
			{	// erase _First, testing _Last before it dies
			if (&_Nextnode(*_Pptr) == _Last._Pptr)
				_Done = true;
			_Erasep(_Pptr);	// _First points to next after erase
			}
		return (_SLIST_ITERATOR(_Pptr));
		}
	}

template<class _Ty, class _Ax>
	void slist<_Ty, _Ax>::clear()
	{	// erase all

 #if _HAS_ITERATOR_DEBUGGING
	this->_Orphan_all();
 #endif /* _HAS_ITERATOR_DEBUGGING */

	_Nodeptr _Pnext;
	_Nodeptr _Pnode = _Myhead;
	_Myhead = 0;
	_Mytail = 0;
	_Mysize = 0;

	for (; _Pnode != 0; _Pnode = _Pnext)
		{	// delete an element
		_Pnext = _Nextnode(_Pnode);
		this->_Alval.destroy(&_Myval(_Pnode));
		_Freenode(_Pnode);
		}
	}

template<class _Ty, class _Ax>
	void slist<_Ty, _Ax>::splice(iterator _Where,
	_Myt& _Right, iterator _First, iterator _Last)
	{	// splice _Right [_First, _Last) at _Where
	if (_First != _Last && (this != &_Right || _Where != _Last))
		{	// worth splicing, do it
		size_type _Count = 0;
		if (this == &_Right)
			;	// just rearrange this slist
		else if (_First == _Right.begin() && _Last == _Right.end())
			_Count = _Right._Mysize;	// splice in whole slist
		else
			_Distance(_First, _Last, _Count);	// splice in partial slist
		_Splice(_Where, _Right, _First, _Last, _Count);
		}
	}

template<class _Ty, class _Ax>
	void slist<_Ty, _Ax>::remove(const _Ty& _Val)
	{	// erase each element matching _Val
	for (iterator _First = begin(); _First != end(); )
		if (*_First == _Val)
			_First = erase(_First);
		else
			++_First;
	}

template<class _Ty, class _Ax>
	template<class _Pr1>
	void slist<_Ty, _Ax>::remove_if(_Pr1 _Pred)
	{	// erase each element satisfying _Pred
	for (iterator _First = begin(); _First != end(); )
		if (_Pred(*_First))
			_First = erase(_First);
		else
			++_First;
	}

template<class _Ty, class _Ax>
	void slist<_Ty, _Ax>::unique()
	{	// erase each element matching previous
	if (2 <= _Mysize)
		{	// worth doing
		iterator _First = begin();
		iterator _After = _First;
		for (++_After; _After != end(); )
			if (*_First == *_After)
				_After = erase(_After);
			else
				_First = _After++;
		}
	}

template<class _Ty, class _Ax>
	template<class _Pr2>
	void slist<_Ty, _Ax>::unique(_Pr2 _Pred)
	{	// erase each element matching previous
	if (2 <= _Mysize)
		{	// worth doing
		iterator _First = begin();
		iterator _After = _First;
		for (++_After; _After != end(); )
			if (_Pred(*_First, *_After))
				_After = erase(_After);
			else
				_First = _After++;
		}
	}

template<class _Ty, class _Ax>
	void slist<_Ty, _Ax>::merge(_Myt& _Right)
	{	// merge in elements from _Right, both ordered by operator<
	if (&_Right != this)
		{	// safe to merge, do it
		_DEBUG_ORDER(begin(), end());
		_DEBUG_ORDER(_Right.begin(), _Right.end());
		for (iterator _First1 = begin();
			_First1 != end() && 0 < _Right._Mysize; )
			{	// merge in an element if in place
			iterator _First2 = _Right.begin();
			while (_First2 != _Right.end()
				&& _DEBUG_LT(*_First2, *_First1))
				++_First2;
			if (_First2 != _Right.begin())
				_Splice(_First1++, _Right, _Right.begin(), _First2, 1);
			else
				++_First1;
			}

		if (0 < _Right._Mysize)
			_Splice(end(), _Right, _Right.begin(), _Right.end(),
				_Right._Mysize);	// splice remainder of _Right
		}
	}

template<class _Ty, class _Ax>
	template<class _Pr3>
	void slist<_Ty, _Ax>::merge(_Myt& _Right, _Pr3 _Pred)
	{	// merge in elements from _Right, both ordered by _Pred
	if (&_Right != this)
		{	// safe to merge, do it
		_DEBUG_ORDER_PRED(begin(), end(), _Pred);
		_DEBUG_ORDER_PRED(_Right.begin(), _Right.end(), _Pred);
		for (iterator _First1 = begin();
			_First1 != end() && 0 < _Right._Mysize; )
			{	// merge in an element if in place
			iterator _First2 = _Right.begin();
			while (_First2 != _Right.end()
				&& _DEBUG_LT_PRED(_Pred, *_First2, *_First1))
				++_First2;
			if (_First2 != _Right.begin())
				_Splice(_First1++, _Right, _Right.begin(), _First2, 1);
			else
				++_First1;
			}

		if (0 < _Right._Mysize)
			_Splice(end(), _Right, _Right.begin(), _Right.end(),
				_Right._Mysize);	// splice remainder of _Right
		}
	}

template<class _Ty, class _Ax>
	void slist<_Ty, _Ax>::sort()
	{	// order sequence, using operator<
	if (2 <= _Mysize)
		{	// worth sorting, do it
		const size_t _MAXBINS = 25;
		_Myt _Tempslist(this->_Alval), _Binslist[_MAXBINS + 1];
		size_t _Maxbin = 0;

		while (!empty())
			{	// sort another element, using bins
			_Tempslist.splice(_Tempslist.begin(), *this, begin());
			size_t _Bin;

			for (_Bin = 0; _Bin < _Maxbin && !_Binslist[_Bin].empty();
				++_Bin)
				{	// merge into ever larger bins
				_Binslist[_Bin].merge(_Tempslist);
				_Binslist[_Bin].swap(_Tempslist);
				}

			if (_Bin == _MAXBINS)
				_Binslist[_Bin - 1].merge(_Tempslist);
			else
				{	// spill to new bin, while they last
				_Binslist[_Bin].swap(_Tempslist);
				if (_Bin == _Maxbin)
					++_Maxbin;
				}
			}

		for (size_t _Bin = 1; _Bin < _Maxbin; ++_Bin)
			_Binslist[_Bin].merge(_Binslist[_Bin - 1]);	// merge up
		swap(_Binslist[_Maxbin - 1]);	// replace from last bin
		}
	}

template<class _Ty, class _Ax>
	template<class _Pr3>
	void slist<_Ty, _Ax>::sort(_Pr3 _Pred)
	{	// order sequence, using _Pred
	if (2 <= _Mysize)
		{	// worth sorting, do it
		const size_t _MAXBINS = 25;
		_Myt _Tempslist(this->_Alval), _Binslist[_MAXBINS + 1];
		size_t _Maxbin = 0;

		while (!empty())
			{	// sort another element, using bins
			_Tempslist.splice(_Tempslist.begin(), *this, begin());
			size_t _Bin;

			for (_Bin = 0; _Bin < _Maxbin && !_Binslist[_Bin].empty();
				++_Bin)
				{	// merge into ever larger bins
				_Binslist[_Bin].merge(_Tempslist, _Pred);
				_Binslist[_Bin].swap(_Tempslist);
				}

			if (_Bin == _MAXBINS)
				_Binslist[_Bin - 1].merge(_Tempslist, _Pred);
			else
				{	// spill to new bin, while they last
				_Binslist[_Bin].swap(_Tempslist);
				if (_Bin == _Maxbin)
					++_Maxbin;
				}
			}

		for (size_t _Bin = 1; _Bin < _Maxbin; ++_Bin)
			_Binslist[_Bin].merge(_Binslist[_Bin - 1],
				_Pred);	// merge up
		swap(_Binslist[_Maxbin - 1]);	// replace with last bin
		}
	}

template<class _Ty, class _Ax>
	void slist<_Ty, _Ax>::reverse()
	{	// reverse sequence
	if (2 <= _Mysize)
		{	// worth doing
		for (_Nodeptr *_Pptr = (++begin())._Pptr; _Pptr != end()._Pptr; )
			{	// move next element to beginning
			iterator _Next = _SLIST_ITERATOR(_Pptr);
			iterator _After = _Next;
			_Splice(begin(), *this, _Next, ++_After, 1);
			}
		}
	}

template<class _Ty, class _Ax>
	typename slist<_Ty, _Ax>::iterator slist<_Ty, _Ax>::previous(const_iterator _Where)
	{	// return predecessor to _Where
	_Nodeptr *_Ppwhere = _Where._Pptr;

	if (_Ppwhere != &_Myhead && _Myhead != 0)
		for (_Nodeptr *_Ppnode = &_Myhead; *_Ppnode != 0;
			_Ppnode = &_Nextnode(*_Ppnode))
			if (&_Nextnode(*_Ppnode) == _Ppwhere)
				return (_SLIST_ITERATOR(_Ppnode));	// success
	return (end());	// failure
	}

template<class _Ty, class _Ax>
	typename slist<_Ty, _Ax>::const_iterator slist<_Ty, _Ax>::previous(const_iterator _Where) const
	{	// return predecessor to _Where
	_Nodeptr *_Ppwhere = _Where._Pptr;

	if (_Ppwhere != &_Myhead && _Myhead != 0)
		for (_Nodeptr *_Ppnode = &_Myhead; *_Ppnode != 0;
			_Ppnode = &_Nextnode(*_Ppnode))
			if (&_Nextnode(*_Ppnode) == _Ppwhere)
				return (_SLIST_CONST_ITERATOR(_Ppnode));	// success
	return (end());	// failure
	}

template<class _Ty, class _Ax>
	void slist<_Ty, _Ax>::_Erasep(_Nodeptr *_Ppnode)
	{	// erase element at _Pnode

 #if _HAS_ITERATOR_DEBUGGING
	if (*_Ppnode == 0)
		_DEBUG_ERROR("slist erase iterator outside range");
	else
		{	// not off end, safe to erase
		_Nodeptr _Pnode = _Nextnode(*_Ppnode);
		_Orphan_ptr(*this, *_Ppnode);
		_Orphan_ptr(*this, _Pnode);

 #else /* _HAS_ITERATOR_DEBUGGING */
	if (*_Ppnode != 0)
		{	// not off end, safe to erase
		_Nodeptr _Pnode = _Nextnode(*_Ppnode);
 #endif /* _HAS_ITERATOR_DEBUGGING */

		if (_Pnode == 0)
			_Mytail = 0;	// erasing tail, new tail unknown

		this->_Alval.destroy(&_Myval(*_Ppnode));
		_Freenode(*_Ppnode);
		*_Ppnode = _Pnode;
		--_Mysize;
		}
		}

template<class _Ty, class _Ax>
	void slist<_Ty, _Ax>::_Insertp(_Nodeptr *_Ppnode,
	const _Ty& _Val)
	{	// insert _Val at *_Ppnode

 #if _HAS_ITERATOR_DEBUGGING
	_Orphan_ptr(*this, *_Ppnode);
 #endif /* _HAS_ITERATOR_DEBUGGING */

	_Nodeptr _Newnode = 0;

	_TRY_BEGIN
	_Newnode = _Buynode(*_Ppnode);
	_Incsize(1);
	this->_Alval.construct(&_Myval(_Newnode), _Val);
	_CATCH_ALL
	if (_Newnode != 0)
		{	// allocation succeeded, constructor failed
		--_Mysize;
		_Freenode(_Newnode);
		}
	_RERAISE;
	_CATCH_END

	if (_Nextnode(_Newnode) == 0)
		_Mytail = _Newnode;	// new tail
	*_Ppnode = _Newnode;
	}

template<class _Ty, class _Ax>
	typename slist<_Ty, _Ax>::_Nodeptr * slist<_Ty, _Ax>::_Getptail() const
	{	// return pointer to pointer to tail
	_Nodeptr *_Ppnode = (_Nodeptr *)&_Myhead;
	if (_Myhead != 0)
		for (; _Nextnode(*_Ppnode) != 0; _Ppnode = &_Nextnode(*_Ppnode))
			;
	return (_Ppnode);
	}

template<class _Ty, class _Ax>
	void slist<_Ty, _Ax>::_Splice(iterator _Where, _Myt& _Right,
	iterator _First, iterator _Last, size_type _Count)
	{	// splice _Right [_First, _Last) before _Where

 #if _HAS_ITERATOR_DEBUGGING
	if (this->_Alval == _Right._Alval)
		{	// same allocator, just relink
		for (iterator _Next = _First; _Next != _Last; )
			_Orphan_ptr(_Right, *(_Next++)._Pptr);
		_Orphan_ptr(_Right, *_Last._Pptr);

 #else /* _HAS_ITERATOR_DEBUGGING */
	if (this->_Alval == _Right._Alval)
		{	// same allocator, just relink
 #endif /* _HAS_ITERATOR_DEBUGGING */

		_Nodeptr *_Pptr = _Getpptr(_Where);
		if (this != &_Right)
			{	// splicing from another slist, adjust counts
			_Incsize(_Count);
			_Right._Mysize -= _Count;
			}

		_Nodeptr _Pnode = *_Pptr;
		if (_Pnode == 0)
			_Mytail = 0;
		if (*_Last._Pptr == 0)
			_Right._Mytail = 0;
		*_Pptr = *_First._Pptr;
		*_First._Pptr = *_Last._Pptr;
		*_Last._Pptr = _Pnode;
		}
	else
		{	// different allocator, copy nodes then erase source
		insert(_Where, _First, _Last);
		_Right.erase(_First, _Last);
		}
		}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
