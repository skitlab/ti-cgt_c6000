// EXPORTED FUNCTIONS
#include <complex>
_STD_BEGIN

template<class _Ty, class _Valbase>
	template<class _Other>
	void _Complex_base<_Ty, _Valbase>::_Div(const complex<_Other>& _Right)
	{	// divide by other complex
	typedef _Ctraits<_Ty> _Myctraits;
	_Ty _Rightreal = (_Ty)_Right.real();
	_Ty _Rightimag = (_Ty)_Right.imag();

	if (_Myctraits::_Isnan(_Rightreal) || _Myctraits::_Isnan(_Rightimag))
		{	// set NaN result
		this->_Val[_RE] = _Myctraits::_Nanv(_Rightreal);
		this->_Val[_IM] = this->_Val[_RE];
		}
	else if ((_Rightimag < 0 ? -_Rightimag : +_Rightimag)
		< (_Rightreal < 0 ? -_Rightreal : +_Rightreal))
		{	// |_Right.imag()| < |_Right.real()|
		_Ty _Wr = _Rightimag / _Rightreal;
		_Ty _Wd = _Rightreal + _Wr * _Rightimag;

		if (_Myctraits::_Isnan(_Wd) || _Wd == 0)
			{	// set NaN result
			this->_Val[_RE] = _Myctraits::_Nanv(_Rightreal);
			this->_Val[_IM] = this->_Val[_RE];
			}
		else
			{	// compute representable result
			_Ty _Tmp = (this->_Val[_RE]
				+ this->_Val[_IM] * _Wr) / _Wd;
			this->_Val[_IM] = (this->_Val[_IM]
				- this->_Val[_RE] * _Wr) / _Wd;
			this->_Val[_RE] = _Tmp;
			}
		}
	else if (_Rightimag == 0)
		{	// set NaN result
		this->_Val[_RE] = _Myctraits::_Nanv(_Rightreal);
		this->_Val[_IM] = this->_Val[_RE];
		}
	else
		{	// 0 < |_Right.real()| <= |_Right.imag()|
		_Ty _Wr = _Rightreal / _Rightimag;
		_Ty _Wd = _Rightimag + _Wr * _Rightreal;

		if (_Myctraits::_Isnan(_Wd) || _Wd == 0)
			{	// set NaN result
			this->_Val[_RE] = _Myctraits::_Nanv(_Rightreal);
			this->_Val[_IM] = this->_Val[_RE];
			}
		else
			{	// compute representable result
			_Ty _Tmp = (this->_Val[_RE] * _Wr + this->_Val[_IM]) / _Wd;
			this->_Val[_IM] = (this->_Val[_IM] * _Wr
				- this->_Val[_RE]) / _Wd;
			this->_Val[_RE] = _Tmp;
			}
		}
	}

template<class _Ty,
	class _Elem,
	class _Tr>
	basic_istream<_Elem, _Tr>& operator>>(
		basic_istream<_Elem, _Tr>& _Istr, complex<_Ty>& _Right)
	{	// extract a complex<_Ty>
	typedef complex<_Ty> _Myt;
	const ctype<_Elem>& _Ctype_fac = use_facet< ctype<_Elem> >(_Istr.getloc());
	_Elem _Ch;
	long double _Real, _Imag = 0;

	if (_Istr >> _Ch && _Ch != _Ctype_fac.widen('('))
		{	// no leading '(', treat as real only
		_Istr.putback(_Ch);
		_Istr >> _Real;
		_Imag = 0;
		}
	else if (_Istr >> _Real >> _Ch && _Ch != _Ctype_fac.widen(','))
		if (_Ch == _Ctype_fac.widen(')'))
			_Imag = 0;	// (real)
		else
			{	// no trailing ')' after real, treat as bad field
			_Istr.putback(_Ch);
			_Istr.setstate(ios_base::failbit);
			}
	else if (_Istr >> _Imag >> _Ch && _Ch != _Ctype_fac.widen(')'))
			{	// no imag or trailing ')', treat as bad field
			_Istr.putback(_Ch);
			_Istr.setstate(ios_base::failbit);
			}

	if (!_Istr.fail())
		{	// store valid result
		_Ty _Tyreal((_Ty)_Real), _Tyimag((_Ty)_Imag);
		_Right = _Myt(_Tyreal, _Tyimag);
		}
	return (_Istr);
	}

template<class _Ty,
	class _Elem,
	class _Tr>
	basic_ostream<_Elem, _Tr>& operator<<(
		basic_ostream<_Elem, _Tr>& _Ostr, const complex<_Ty>& _Right)
	{	// insert a complex<_Ty>
	const ctype<_Elem>& _Ctype_fac = use_facet< ctype<_Elem> >(_Ostr.getloc());
	basic_ostringstream<_Elem, _Tr, allocator<_Elem> > _Sstr;

	_Sstr.flags(_Ostr.flags());
	_Sstr.imbue(_Ostr.getloc());
	_Sstr.precision(_Ostr.precision());
	_Sstr << _Ctype_fac.widen('(') << real(_Right)
		<< _Ctype_fac.widen(',') << imag(_Right)
		<< _Ctype_fac.widen(')');

	basic_string<_Elem, _Tr, allocator<_Elem> > _Str = _Sstr.str();
	return (_Ostr << _Str.c_str());
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
