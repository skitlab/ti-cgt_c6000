// EXPORTED FUNCTIONS
#include <memory>
_STD_BEGIN

template<class _Ty>
	pair<_Ty _FARQ *, _PDFT>
		get_temporary_buffer(_PDFT _Count)
	{	// get raw temporary buffer of up to _Count elements
	_Ty _FARQ *_Pbuf;

	for (_Pbuf = 0; 0 < _Count; _Count /= 2)
		if ((_Pbuf = (_Ty _FARQ *)operator new(
			(_SIZT)_Count * sizeof (_Ty), nothrow)) != 0)
			break;

	return (pair<_Ty _FARQ *, _PDFT>(_Pbuf, _Count));
	}

template<class _InIt,
	class _FwdIt>
	_FwdIt _Uninit_copy(_InIt _First, _InIt _Last, _FwdIt _Dest,
		_Nonscalar_ptr_iterator_tag)
	{	// copy [_First, _Last) to raw _Dest, arbitrary type
	_DEBUG_RANGE(_First, _Last);
	_DEBUG_POINTER(_Dest);
	_FwdIt _Next = _Dest;

	_TRY_BEGIN
	for (; _First != _Last; ++_Dest, ++_First)
		_Construct(&*_Dest, *_First);
	_CATCH_ALL
	for (; _Next != _Dest; ++_Next)
		_Destroy(&*_Next);
	_RERAISE;
	_CATCH_END
	return (_Dest);
	}

template<class _InIt,
	class _FwdIt,
	class _Alloc>
	_FwdIt _Uninit_copy(_InIt _First, _InIt _Last, _FwdIt _Dest,
		_Alloc& _Al, _Nonscalar_ptr_iterator_tag)
	{	// copy [_First, _Last) to raw _Dest, using _Al, arbitrary type
	_DEBUG_RANGE(_First, _Last);
	_DEBUG_POINTER(_Dest);
	_FwdIt _Next = _Dest;

	_TRY_BEGIN
	for (; _First != _Last; ++_Dest, ++_First)
		_Al.construct(_Dest, *_First);
	_CATCH_ALL
	for (; _Next != _Dest; ++_Next)
		_Al.destroy(_Next);
	_RERAISE;
	_CATCH_END
	return (_Dest);
	}

template<class _FwdIt,
	class _Tval>
	void _Uninit_fill(_FwdIt _First, _FwdIt _Last, const _Tval& _Val,
		_Nonscalar_ptr_iterator_tag)
	{	// copy _Val throughout raw [_First, _Last), arbitrary type
	_DEBUG_RANGE(_First, _Last);
	_FwdIt _Next = _First;

	_TRY_BEGIN
	for (; _First != _Last; ++_First)
		_Construct(&*_First, _Val);
	_CATCH_ALL
	for (; _Next != _First; ++_Next)
		_Destroy(&*_Next);
	_RERAISE;
	_CATCH_END
	}

template<class _FwdIt,
	class _Diff,
	class _Tval>
	void _Uninit_fill_n(_FwdIt _First, _Diff _Count, const _Tval& _Val,
		_Nonscalar_ptr_iterator_tag)
	{	// copy _Count *_Val to raw _First, arbitrary type

 #if _HAS_ITERATOR_DEBUGGING
//	if (_Count < 0)
//		_DEBUG_ERROR("negative count in uninitialized fill");
 #endif /* _HAS_ITERATOR_DEBUGGING */

	_FwdIt _Next = _First;

	_TRY_BEGIN
	for (; 0 < _Count; --_Count, ++_First)
		_Construct(&*_First, _Val);
	_CATCH_ALL
	for (; _Next != _First; ++_Next)
		_Destroy(&*_Next);
	_RERAISE;
	_CATCH_END
	}

template<class _FwdIt,
	class _Diff,
	class _Tval,
	class _Alloc>
	void _Uninit_fill_n(_FwdIt _First, _Diff _Count,
		const _Tval& _Val, _Alloc& _Al, _Nonscalar_ptr_iterator_tag)
	{	// copy _Count *_Val to raw _First, using _Al, arbitrary type

 #if _HAS_ITERATOR_DEBUGGING
//	if (_Count < 0)
//		_DEBUG_ERROR("negative count in uninitialized fill");
 #endif /* _HAS_ITERATOR_DEBUGGING */

	_FwdIt _Next = _First;

	_TRY_BEGIN
	for (; 0 < _Count; --_Count, ++_First)
		_Al.construct(_First, _Val);
	_CATCH_ALL
	for (; _Next != _First; ++_Next)
		_Al.destroy(_Next);
	_RERAISE;
	_CATCH_END
	}

template<class _Ty>
	_Temp_iterator<_Ty>::_Temp_iterator(_PDFT _Count)
	{	// construct from desired temporary buffer size
	pair<_Pty, _PDFT> _Pair =
		_STD get_temporary_buffer<_Ty>(_Count);
	_Buf._Begin = _Pair.first;
	_Buf._Current = _Pair.first;
	_Buf._Hiwater = _Pair.first;
	_Buf._Size = _Pair.second;
	_Pbuf = &_Buf;
	}

template<class _Ty>
	_Temp_iterator<_Ty>::_Temp_iterator(const _Temp_iterator<_Ty>& _Right)
	{	// construct from _Right (share active buffer)
	_Buf._Begin = 0;	// clear stored buffer, to be tidy
	_Buf._Current = 0;
	_Buf._Hiwater = 0;
	_Buf._Size = 0;
	*this = _Right;
	}

template<class _Ty>
	_Temp_iterator<_Ty>::~_Temp_iterator()
	{	// destroy the object
	if (_Buf._Begin != 0)
		{	// destroy any constructed elements in buffer
		for (_Pty _Next = _Buf._Begin;
			_Next != _Buf._Hiwater; ++_Next)
			_Destroy(&*_Next);
		_STD return_temporary_buffer(_Buf._Begin);
		}
	}

_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
